from aiohttp import ClientSession
import asyncio
import json

from config import crypto_pay_api_token_live, crypto_pay_api_token_test, crypto_pay_live

if crypto_pay_live:
    crypto_pay_url = 'https://pay.crypt.bot/'
    headers = {"Crypto-Pay-API-Token": crypto_pay_api_token_live}
else:
    crypto_pay_url = 'https://testnet-pay.crypt.bot/'
    headers = {"Crypto-Pay-API-Token": crypto_pay_api_token_test}


async def crypto_pay_auth():
    async with ClientSession(headers=headers) as s:
        req = await s.post(f'{crypto_pay_url}api/getMe')
        page_json = json.loads(await req.text())


async def crypto_pay_create_invoice(currency: str, amount: int, ):
    exchange_rate = await _getExchangeRates(currency)
    params = (
        ('asset', currency),
        ('amount', str(amount / exchange_rate))
    )
    async with ClientSession(headers=headers) as s:
        req = await s.post(f'{crypto_pay_url}api/createInvoice', data=params)
        page_json = json.loads(await req.text())
        # print(page_json)
        # print(page_json['result']['invoice_id'])
        # print(page_json['result']['pay_url'])
        return page_json['result']['pay_url'], page_json['result']['invoice_id']


async def _getExchangeRates(currency: str):
    async with ClientSession(headers=headers) as s:
        req = await s.post(f'{crypto_pay_url}api/getExchangeRates')
        page_json = json.loads(await req.text())
        for item in page_json['result']:
            if item['source'] == currency and item['target'] == 'RUB':
                return float(item['rate'])


async def crypto_pay_check_invoice(invoice_id: int):
    params = (('invoice_ids', invoice_id),)
    async with ClientSession(headers=headers) as s:
        req = await s.post(f'{crypto_pay_url}api/getInvoices', data=params)
        page_json = json.loads(await req.text())
        # print(page_json['result']['items'][0]['status'])
        if page_json['result']['items'][0]['status'] == 'paid':
            return True
        return False


if __name__ == "__main__":
    loop = asyncio.get_event_loop()
    # currency in 'BTC' or 'TON' or 'ETH' or 'USDT' or 'USDC'
    loop.run_until_complete(crypto_pay_create_invoice('USDT', 125))
    loop.run_until_complete(crypto_pay_check_invoice(17268))
